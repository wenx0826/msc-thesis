# CPEE Layout

Themable, flexible BPMN auto-layout library. Visualization and editing. Event-driven. Minimal dependencies (jQuery).
