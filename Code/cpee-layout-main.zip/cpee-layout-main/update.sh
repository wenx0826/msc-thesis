cp ../cpee/cockpit/js/wfadaptor.js .
cp ../cpee/cockpit/css/wfadaptor.css .
cp ../cpee/cockpit/js/extended_columns.js .
cp ../cpee/cockpit/css/extended_columns-label.css .
cp ../cpee/cockpit/css/extended_columns-svg.css .
cp -r ../cpee/cockpit/themes/base.js themes/.
cp -r ../cpee/cockpit/themes/extended themes/.
cp -r ../cpee/cockpit/themes/preset themes/.
cp -r ../cpee/cockpit/themes/presetaltid themes/.
cp -r ../cpee/cockpit/themes/packed themes/.
cp -r ../cpee/cockpit/themes/dataflow themes/.
